package com.bbva.mneo;

import com.bbva.elara.domain.transaction.Advice;
import com.bbva.elara.domain.transaction.AdviceType;
import com.bbva.elara.domain.transaction.Context;
import com.bbva.elara.domain.transaction.TransactionParameter;
import com.bbva.elara.domain.transaction.request.TransactionRequest;
import com.bbva.elara.domain.transaction.request.body.CommonRequestBody;
import com.bbva.elara.domain.transaction.request.header.CommonRequestHeader;
import com.bbva.elara.test.osgi.DummyBundleContext;
import com.bbva.mneo.dto.customers.CustomersDTO;
import com.bbva.mneo.lib.r001.MNEOR001;

import java.util.ArrayList;
import javax.annotation.Resource;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * Test for transaction MNEOT00101MXTransaction
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
		"classpath:/META-INF/spring/elara-test.xml",
		"classpath:/META-INF/spring/MNEOT00101MXTest.xml" })
public class MNEOT00101MXTransactionTest {
	private static final Logger LOGGER = LoggerFactory.getLogger(MNEOT00101MXTransactionTest.class);

	@Autowired
	private MNEOT00101MXTransaction transaction;

	@Resource(name = "dummyBundleContext")
	private DummyBundleContext bundleContext;
	@Resource
	private MNEOR001 mneoR001;
	/*
	@Resource(name = "mneor001")
	private MNEOR001 mneor001;*/

	@Mock
	private CommonRequestHeader header;

	@Mock
	private TransactionRequest transactionRequest;
	
	private CustomersDTO customers;


	@Before
	public void initializeClass() throws Exception {
		// Initializing mocks
		MockitoAnnotations.initMocks(this);
		// Start BundleContext
		this.transaction.start(bundleContext);
		// Setting Context
		this.transaction.setContext(new Context());
		// Set Body
		CommonRequestBody commonRequestBody = new CommonRequestBody();
		commonRequestBody.setTransactionParameters(new ArrayList<>());
		this.transactionRequest.setBody(commonRequestBody);
		// Set Header Mock
		this.transactionRequest.setHeader(header);
		// Set TransactionRequest
		this.transaction.getContext().setTransactionRequest(transactionRequest);
		this.transactionRequest = Mockito.mock(TransactionRequest.class);
		commonRequestBody.setTransactionParameters(new ArrayList<TransactionParameter>());
		
		this.transactionRequest.setHeader(header);
		CustomersDTO customers = new CustomersDTO();
		customers.setCustomerId(1);
		customers.setCustomerName("monica");
		customers.setAddress("");
		customers.setCity("");
		customers.setState("");
		customers.setZipCode("");
	}
	@Test
	public void executeTestInsertar() {
		LOGGER.info("Insert transaciton test");
		Mockito.doReturn(customers).when(mneoR001).executeInsert(customers);
		addParameter("entrada", "0");
		addParameter("customersIn", customers);
		this.transaction.execute();
		CustomersDTO result = (CustomersDTO) getParameter("customersOut");
		Mockito.verify(mneoR001).executeInsert(customers);
		Assert.assertEquals(customers, result);
	}
	
	@Test
	public void executeTest() {
		this.addParameter("entrada", "0");this.transaction.execute();
		this.addParameter("entrada", "1");this.transaction.execute();
		this.addParameter("entrada", "2");this.transaction.execute();
		this.addParameter("entrada", "3");this.transaction.execute();
		
		Advice advice = new Advice();
		advice.setCode("MNEOR");
		advice.setDescription("description");
		advice.setType(AdviceType.W);
		this.transaction.getAdviceList().add(advice);
		this.transaction.execute();
	}
	
	@Test
	public void executeTestUpdate() {

		LOGGER.info("execute test update");
		Mockito.doReturn(customers).when(mneoR001).executeUpadate(customers);
		addParameter("entrada", "1");
		addParameter("customersIn", customers);
		this.transaction.execute();
		CustomersDTO result = (CustomersDTO) getParameter("customersOut");
		Mockito.verify(mneoR001).executeUpadate(customers);
		Assert.assertEquals(customers, result);
	}

	@Test
	public void executeTestDelete() {

		LOGGER.info("Delete transaciton test");
		addParameter("entrada", "2");
		addParameter("customersIn", customers);
		this.transaction.execute();
		Assert.assertNull(getParameter("customersOut"));
		Mockito.verify(mneoR001).executeDeleteById(customers);
	}

	@Test
	public void executeTestGetByName() {

		LOGGER.info("GetByName transaciton test");
		Mockito.doReturn(customers).when(mneoR001).executeGetByName(customers);
		addParameter("entrada", "3");
		addParameter("customersIn", customers);
		this.transaction.execute();
		CustomersDTO result = (CustomersDTO) getParameter("customersOut");
		Mockito.verify(mneoR001).executeGetByName(customers);
		Assert.assertEquals(customers, result);
	}

	@Test
	public void executeTestSetAdvice() {
		LOGGER.info("Set correct advice transaciton test");
		Advice advice = new Advice();
		advice.setCode("MNEO01317007");
		advice.setDescription("Advice ");
		advice.setType(AdviceType.W);
		// add the advice
		this.transaction.getAdviceList().add(advice);

		this.transaction.execute();
	}
	
	@Test
	public void testSetAdviceIncorrect() {
		LOGGER.info("Set incorrect advice transaciton test");
		Advice advice = new Advice();
		advice.setCode("MNEO01317010");
		advice.setDescription("Advice ");
		advice.setType(AdviceType.W);
		
		
		this.transaction.getAdviceList().add(advice);

		this.transaction.execute();
	}
	/*
	@Test
	public void executeInsertTestT() {
		LOGGER.info("Entrando a ExecuteInsertTest");
		Mockito.doReturn("01").when(header).getHeaderParameter(RequestHeaderParamsName.CHANNELCODE);
	}*/

	@Test
	public void testNotNull(){
	    // Example to Mock the Header
		// Mockito.doReturn("ES").when(header).getHeaderParameter(RequestHeaderParamsName.COUNTRYCODE);
		Assert.assertNotNull(this.transaction);
		this.transaction.execute();
	}

	// Add Parameter to Transaction
	private void addParameter(final String parameter, final Object value) {
		final TransactionParameter tParameter = new TransactionParameter(parameter, value);
		transaction.getContext().getParameterList().put(parameter, tParameter);
	}

	// Get Parameter from Transaction
	private Object getParameter(final String parameter) {
		final TransactionParameter param = transaction.getContext().getParameterList().get(parameter);
		return param != null ? param.getValue() : null;
	}
}
