package com.bbva.mneo.batch;

import org.springframework.batch.item.ItemProcessor;

import com.bbva.mneo.dto.customers.CustomersDTO;

public class ProccesorCustomer implements ItemProcessor<CustomersDTO, CustomersDTO> {

	@Override
	public CustomersDTO process(CustomersDTO customers) throws Exception {
		
		customers.setZipCode(customers.getZipCode()+"11");
		return customers;
	}

	
	
}
