package com.bbva.mneo.batch;



import java.io.File;

import org.slf4j.Logger;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import com.bbva.mneo.lib.r001.MNEOR001;


public class CustomersReadFile implements Tasklet,StepExecutionListener {
	String FileName;//Esta parte se recomienda ponerla en private 
	boolean status;//Esta parte se recomienda ponerla en private 

	private static final Logger LOGGER = org.slf4j.LoggerFactory.getLogger(CustomersReadFile.class);
	MNEOR001 mneoR001;
	
	//que valide el nombre y que valide si esta vacio 

	


	@Override
	public RepeatStatus execute(StepContribution arg0, ChunkContext arg1) throws Exception {
		// TODO Auto-generated method stub
		//Logica mandarle el nombre del archivo que se valida 
		LOGGER.info("Entrando a CustomersReadFile");
		File archivo = new File(FileName);
		if(archivo.exists()) {
			LOGGER.info("El archivo- "+archivo+" Existe");
			if(archivo.length()>0) {
				LOGGER.info("Tamaño del archivo: "+archivo.length());
				// aqui hacemos un delete
				mneoR001.deleteAll();
				status=true;
				
			}else if (archivo.length()<=0) {
				LOGGER.info("El achivo esta vacio");
				status=false;
				
			}
			
			
		}else {
			LOGGER.info("El archivo "+archivo+" no existe");
		}
			
		
		//ExitStatus.COMPLETED.getExitCode();//Aqui lo cargamos 
		//LOGGER.info("Estatus :"+ );
		
		return RepeatStatus.FINISHED;
	}


	@Override
	public ExitStatus afterStep(StepExecution arg0) {
		// TODO Auto-generated method stub
		if(status==true) {
		return ExitStatus.COMPLETED;
		}
		else {
			return ExitStatus.FAILED;
	}
	}


	@Override
	public void beforeStep(StepExecution arg0) {
		// TODO Auto-generated method stub
		
		
		
	}
	
	
	public boolean isStatus() {
		return status;
	}


	public void setStatus(boolean status) {
		this.status = status;
	}


	public MNEOR001 getMneoR001() {
		return mneoR001;
	}


	public void setMneoR001(MNEOR001 mneoR001) {
		this.mneoR001 = mneoR001;
	}


	public String getFileName() {
		return FileName;
	}


	public void setFileName(String fileName) {
		FileName = fileName;
	}
	
	
	
}
