package com.bbva.mneo.batch;

import static org.mockito.Mockito.verify;

import java.util.HashMap;

import javax.annotation.Resource;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.test.JobLauncherTestUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bbva.mneo.lib.r001.MNEOR001;

/**
 * Test for batch process MNEOJ001-01-MX
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"classpath:/META-INF/spring/batch/beans/MNEOJ001-01-MX-beans.xml",
		"classpath:/META-INF/spring/batch/jobs/jobs-MNEOJ001-01-MX-context.xml",
		"classpath:/META-INF/spring/jobs-MNEOJ001-01-MX-runner-context.xml"})
public class MNEOJ00101MXFunctionalTest{//C:\Users\w10\Documents\workspace-spring-tool-suite-4-curso\MNEOJ001-01-MX
	public static final String PATH1 = "C:\\Users\\w10\\Documents\\workspace-spring-tool-suite-4-curso\\MNEOJ001-01-MX\\src\\test\\resources\\datosTest.txt";
	public static final String PATH2 = "C:\\Users\\w10\\Documents\\workspace-spring-tool-suite-4-curso\\MNEOJ001-01-MX\\src\\test\\resources\\testincorrecto.txt";
	public static final String PATHVACIO = "C:\\Users\\w10\\Documents\\workspace-spring-tool-suite-4-curso\\MNEOJ001-01-MX\\src\\test\\resources\\ArchivoVacio.txt";
	public static final String INPUT_FILE = "inputFile";
	public static final String FILE = "file";
	@Autowired
	private JobLauncherTestUtils jobLauncherTestUtils;
	
	@Resource(name = "mneoR001")
	private MNEOR001 mneoR001;

	@Test
	public void testLaunchJob() throws Exception {
		//TODO implements job launch test
		//Without parameters (use this implementation if job not need parameters)
		//final JobExecution jobExecution = jobLauncherTestUtils.launchJob();
		
		//With parameters (use this implementation if job needs parameters comment first implementation) 
		/*********************** Parameters Definition ***********************/
		//First parameter
		//final JobParameter jobParameter = new JobParameter("MMNEO_D02_22042022_customers.txt");
		//final JobParameter jobParameter1 = new JobParameter("ParamValue");
		final JobParameter jobParameterInputFile = new JobParameter("file:\\"+PATH1);
		final JobParameter jobParameterFile = new JobParameter(PATH1);
		final HashMap<String, JobParameter> parameters = new HashMap<String, JobParameter>();
		parameters.put(INPUT_FILE, jobParameterInputFile);
		parameters.put(FILE, jobParameterFile);
		final JobParameters jobParameters = new JobParameters(parameters);
		final JobExecution jobExecution = jobLauncherTestUtils.launchJob(jobParameters);
		verify(mneoR001).deleteAll();
		//Add parameters to job
		//final HashMap<String, JobParameter> parameters = new HashMap<String, JobParameter>();
		//parameters.put("readFile", jobParameter);
		//parameters.put("paramName", jobParameter1);
		//final JobParameters jobParameters = new JobParameters(parameters);
		//final JobExecution jobExecution1 = jobLauncherTestUtils.launchJob(jobParameters);
		
		//TODO implements job launch test Assert's
		Assert.assertTrue(jobExecution.getExitStatus().equals(ExitStatus.COMPLETED));
	}
	@Test
	public void testDontExistFile() throws Exception {	

		//First parameter
		final JobParameter jobParameterInputFile = new JobParameter("file:\\"+PATH2);
		final JobParameter jobParameterFile = new JobParameter(PATH2);
		//Add parameters to job
		final HashMap<String, JobParameter> parameters = new HashMap<String, JobParameter>();
		parameters.put(INPUT_FILE, jobParameterInputFile);
		parameters.put(FILE, jobParameterFile);
		final JobParameters jobParameters = new JobParameters(parameters);
		final JobExecution jobExecution = jobLauncherTestUtils.launchJob(jobParameters);
		
		Assert.assertTrue(jobExecution.getExitStatus().getExitCode().equals(ExitStatus.FAILED.getExitCode()));
	}

	@Test
	public void testFileEmpty() throws Exception {	

		//First parameter
		final JobParameter jobParameterInputFile = new JobParameter("file:\\"+PATHVACIO);
		final JobParameter jobParameterFile = new JobParameter(PATHVACIO);
		//Add parameters to job
		final HashMap<String, JobParameter> parameters = new HashMap<String, JobParameter>();
		parameters.put(INPUT_FILE, jobParameterInputFile);
		parameters.put(FILE, jobParameterFile);
		final JobParameters jobParameters = new JobParameters(parameters);
		final JobExecution jobExecution = jobLauncherTestUtils.launchJob(jobParameters);
		
		Assert.assertTrue(jobExecution.getExitStatus().getExitCode().equals(ExitStatus.FAILED.getExitCode()));
	}
}
