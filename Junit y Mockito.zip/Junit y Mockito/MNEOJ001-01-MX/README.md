# MNEOJ001-01-MX

job para carga de informacion en BD