package com.bbva.mneo.batch;

import java.util.Arrays;
import java.util.HashMap;

import javax.annotation.Resource;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.test.JobLauncherTestUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bbva.mneo.dto.customers.CustomersDTO;
import com.bbva.mneo.lib.r001.MNEOR001;

/**
 * Test for batch process MNEOJ002-01-MX
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"classpath:/META-INF/spring/batch/beans/MNEOJ002-01-MX-beans.xml","classpath:/META-INF/spring/batch/jobs/jobs-MNEOJ002-01-MX-context.xml","classpath:/META-INF/spring/jobs-MNEOJ002-01-MX-runner-context.xml"})
public class MNEOJ00201MXFunctionalTest{

public static final String PATH = "C:\\Users\\w10\\Documents\\workspace-spring-tool-suite-4-curso\\MNEOJ002-01-MX\\src\\test\\Salidatxt.txt";
	
	public static final String FILE = "file";

	@Resource(name = "mneoR001")
	private MNEOR001 mneoR001;

	@Autowired
	private JobLauncherTestUtils jobLauncherTestUtils;


	@Test
	public void testLaunchJob() throws Exception {
		//TODO implements job launch test
		//Without parameters (use this implementation if job not need parameters)
		//final JobExecution jobExecution = jobLauncherTestUtils.launchJob();
		
		//With parameters (use this implementation if job needs parameters comment first implementation) 
		/*********************** Parameters Definition ***********************/
		//First parameter
		final JobParameter jobParameter = new JobParameter(PATH);
		//Add parameters to job
		final HashMap<String, JobParameter> parameters = new HashMap<String, JobParameter>();
		parameters.put(FILE, jobParameter);
		final JobParameters jobParameters = new JobParameters(parameters);

		CustomersDTO customersDTO = new CustomersDTO();
		customersDTO.setCustomerId(1);
		customersDTO.setCustomerName("xavier");
		customersDTO.setAddress("Mexico");
		customersDTO.setCity("Edomex");
		customersDTO.setState("Texcoco");
		customersDTO.setZipCode("123456");
		Mockito.doReturn(Arrays.asList(customersDTO)).when(mneoR001).executeGetListCustomer(2, 1);
		Mockito.doReturn(null).when(mneoR001).executeGetListCustomer(2, 3);
		final JobExecution jobExecution = jobLauncherTestUtils.launchJob(jobParameters);

		Mockito.verify(mneoR001).executeGetListCustomer(2, 1);
		Mockito.verify(mneoR001).executeGetListCustomer(2, 3);
		Mockito.verify(mneoR001,Mockito.never()).executeGetListCustomer(2, 5);
		
		Assert.assertTrue(jobExecution.getExitStatus().equals(ExitStatus.COMPLETED));
	}
}
