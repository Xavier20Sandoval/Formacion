package com.bbva.mneo.batch;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.List;

import org.springframework.batch.item.ItemWriter;

import com.bbva.apx.exception.io.IOException;
import com.bbva.mneo.dto.customers.CustomersDTO;

public class CustomerWriterDB implements ItemWriter<List<CustomersDTO>> {
	
	String file;
	


	public String getFile() {
		return file;
	}
	public void setFile(String file) {
		this.file = file;
	}
	@Override
	public void write(List<? extends List<CustomersDTO>> listListCustomerDTO) throws Exception {
		//Es una lista de listas 
		// TODO Auto-generated method stub
		for(List<CustomersDTO> listCustomerDTO:listListCustomerDTO) {
			writerListCustomerFile(file, listCustomerDTO);
		}
		
	}
	private void writerListCustomerFile(String file,List<CustomersDTO> listCustomer ) throws java.io.IOException {
		
		BufferedWriter bWriter=new BufferedWriter(new FileWriter(file,true));
		
		for(CustomersDTO customersDTO : listCustomer) {
			bWriter.append(String.valueOf(customersDTO.getCustomerId())).append("|")
			.append(customersDTO.getCustomerName()).append("|")
			.append(customersDTO.getAddress()).append("|")
			.append(customersDTO.getCity()).append("|")
			.append(customersDTO.getState()).append("|")
			.append(customersDTO.getZipCode()).append("\n");
			
		}
		bWriter.close();
	}


}
