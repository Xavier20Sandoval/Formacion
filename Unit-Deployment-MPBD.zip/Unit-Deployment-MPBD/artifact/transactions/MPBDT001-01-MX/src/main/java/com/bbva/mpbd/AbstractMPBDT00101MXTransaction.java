package com.bbva.mpbd;

import java.util.List;

import com.bbva.elara.transaction.AbstractTransaction;
import com.bbva.mpbd.dto.employees.EmployeesDTO;

/**
 * In this class, the input and output data is defined automatically through the setters and getters.
 */
public abstract class AbstractMPBDT00101MXTransaction extends AbstractTransaction {

	public AbstractMPBDT00101MXTransaction(){
	}


	/**
	 * Return value for input parameter entrada
	 */
	protected String getEntrada(){
		return (String)this.getParameter("entrada");
	}

	/**
	 * Return value for input parameter employeesIn
	 */
	protected EmployeesDTO getEmployeesin(){
		return (EmployeesDTO)this.getParameter("employeesIn");
	}

	/**
	 * Set value for EmployeesDTO output parameter employeesOut
	 */
	protected void setEmployeesout(final EmployeesDTO field){
		this.addParameter("employeesOut", field);
	}
	protected void setLista(final List<EmployeesDTO> field){
		this.addParameter("lista", field);
	}
}
