package com.bbva.mpbd.lib.r001.impl;



import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bbva.apx.exception.db.DuplicateKeyException;
import com.bbva.apx.exception.db.NoResultException;
import com.bbva.apx.exception.db.TimeoutException;
import com.bbva.mpbd.dto.employees.EmployeesDTO;

/**
 * The MPBDR001Impl class...
 */
public class MPBDR001Impl extends MPBDR001Abstract {

	private static final Logger LOGGER = LoggerFactory.getLogger(MPBDR001Impl.class);

	/**
	 * The execute method...
	 */
	@Override
	public EmployeesDTO executeInsert(EmployeesDTO employees) {
		// TODO Auto-generated method stub

		int result = 0;
		if ((validarPhone(employees.getEmployeePhone()) == true || employees.getEmployeePhone() == null)
				&& (validarCorreo(employees.getEmployeeEmail()) == true || employees.getEmployeeEmail() == null)) {
			try {

				result = this.jdbcUtils.update("insert", employees.getEmployeeNumber(), employees.getEmployeeName(),
						employees.getEmployeeDepartment(), employees.getEmployeeRFC(), employees.getEmployeeEmail(),
						employees.getEmployeePhone(), employees.getEmployeeAddress(),
						employees.getEmployeeRegistrationDate(), employees.getEmployeeStatus(),
						employees.getEmployeeSalary());

			} catch (DuplicateKeyException e) {
				LOGGER.error("ocurrio un problema se duplico el key en la tabla de customer");
				addAdvice("MPBD01317004");
				// TODO: handle exception
			} catch (TimeoutException e) {
				LOGGER.error("ocurrio un problema se excedio el tiempo para insertar en la tabla customers");
				addAdvice("MPBD01317005");
				// TODO: handle exception
			}
			LOGGER.info("El resultado del insert es {}", result);

		} else {
			// LOGGER.info("Correo o numeros invalidos");

		}
		return employees;

	}

	@Override
	public void executeDeleteByName(EmployeesDTO employess) {
		// TODO Auto-generated method stub
		LOGGER.info("Entrando al metodo executeDeleteById");

		int result = 0;
		try {
			Map<String, Object> params = new HashMap<>();
			params.put("status", employess.getEmployeeStatus());
			params.put("name", employess.getEmployeeName());
			result = this.jdbcUtils.update("deleteStatus", params);
		} catch (TimeoutException e) {
			LOGGER.error("Ocurrio un problema se excedio el tiempo para actializar las tablas customers ");
			addAdvice("MPBD1317005");
		}
		LOGGER.info("El resultado de delete es: ", result);
	}

	@Override
	public EmployeesDTO executeUpdateByName(EmployeesDTO employees) {
		// TODO Auto-generated method stub
		LOGGER.info("Entrando al metodo executeUpdate");

		int result = 0;
		try {
			Map<String, Object> params = new HashMap<>();

			params.put("number", employees.getEmployeeNumber());
			params.put("department", employees.getEmployeeDepartment());
			params.put("RFC", employees.getEmployeeRFC());
			params.put("email", employees.getEmployeeEmail());
			params.put("phone", employees.getEmployeePhone());
			params.put("address", employees.getEmployeeAddress());
			params.put("registration_date", employees.getEmployeeRegistrationDate());
			params.put("status", employees.getEmployeeStatus());
			params.put("salary", employees.getEmployeeSalary());
			params.put("name", employees.getEmployeeName());
			result = this.jdbcUtils.update("updateEmployeesName", params);

		} catch (DuplicateKeyException e) {
			LOGGER.error("ocurrio un problema se duplico el key en la tabla de customer");
			addAdvice("MPBD01317004");
			// TODO: handle exception
		} catch (TimeoutException e) {
			LOGGER.error("ocurrio un problema se excedio el tiempo para insertar en la tabla customers");
			addAdvice("MPBD01317005");
			// TODO: handle exception
		}
		LOGGER.info("El resultado del upate es {}", result);
		return employees;

	}

	@Override
	public EmployeesDTO executeGetByName(EmployeesDTO employees) {
		// TODO Auto-generated method stub
		LOGGER.info("Entrando al metodo executeGetByName");
		EmployeesDTO empleado = new EmployeesDTO();
		
		try {
			
			Map<String, Object> params = new HashMap<>();
			params.put("name", employees.getEmployeeName());
			params.put("number", employees.getEmployeeNumber());
			List<Map<String, Object>> lista = new ArrayList<Map<String, Object>>();
			lista = this.jdbcUtils.queryForList("getEmployees", params);
			
			LOGGER.info("Tamlista="+lista.size());
			
			if (lista.size() > 1)
			{
				LOGGER.info("Entrando a buscar el registro");
				for (Map<String, Object> map : lista) {
					if (empleado.equals(map.get("EMPLOYEE_NAME").toString())) {
						empleado.setEmployeeNumber(Integer.parseInt(map.get("EMPLOYEE_NUMBER").toString()));
						empleado.setEmployeeName(map.get("EMPLOYEE_NAME").toString());
						empleado.setEmployeeDepartment(map.get("EMPLOYEE_DEPARTMENT").toString());
						empleado.setEmployeeRFC(map.get("EMPLOYEE_RFC").toString());
						empleado.setEmployeeEmail(map.get("EMPLOYEE_EMAIL").toString());
						empleado.setEmployeePhone(map.get("EMPLOYEE_PHONE").toString());
						empleado.setEmployeeAddress(map.get("EMPLOYEE_ADDRESS").toString());
						empleado.setEmployeeRegistrationDate((Date)map.get("EMPLOYEE_REGISTRATION_DATE"));
						empleado.setEmployeeStatus(Integer.parseInt(map.get("EMPLOYEE_STATUS").toString()));
						empleado.setEmployeeSalary(Integer.parseInt(map.get("SALARY").toString()));
						break;
					}

				}
				LOGGER.info("Saliendo del if encontrar registros");
			} else {
				LOGGER.info("Entrando al else");
				
				empleado.setEmployeeNumber(Integer.parseInt(lista.get(0).get("EMPLOYEE_NUMBER").toString()));
				empleado.setEmployeeName(lista.get(0).get("EMPLOYEE_NAME").toString());
				empleado.setEmployeeDepartment(lista.get(0).get("EMPLOYEE_DEPARTMENT").toString());
				empleado.setEmployeeRFC(lista.get(0).get("EMPLOYEE_RFC").toString());
				empleado.setEmployeeEmail(lista.get(0).get("EMPLOYEE_EMAIL").toString());
				empleado.setEmployeePhone(lista.get(0).get("EMPLOYEE_PHONE").toString());
				empleado.setEmployeeAddress(lista.get(0).get("EMPLOYEE_ADDRESS").toString());
				//String dateString = lista.get(0).get("EMPLOYEE_REGISTRATION_DATE").toString();
				//DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.S", Locale.ENGLISH);
				//LocalDateTime dateTime = LocalDateTime.parse(dateString, formatter);
				//Date date = Date.from(dateTime.atZone(ZoneId.systemDefault()).toInstant());
				empleado.setEmployeeRegistrationDate(((Date)lista.get(0).get("EMPLOYEE_REGISTRATION_DATE")));
				//employeRes.setDate(date);
				// empleado.setEmployeeRegistartionDate();
				empleado.setEmployeeStatus(Integer.parseInt(lista.get(0).get("EMPLOYEE_STATUS").toString()));
				empleado.setEmployeeSalary(Integer.parseInt(lista.get(0).get("SALARY").toString()));
			}
			LOGGER.info("Saliendo del else");

		} catch (NoResultException e) {
			LOGGER.error("Ocurrio un problema al obtener el customer DB");
			addAdvice("MPBD1317008");
		}
		LOGGER.info("Saliendo del metodo executeGetByName");
		return empleado;
	}
	public List<EmployeesDTO> executeGetAll() {
		// TODO Auto-generated method stub

		List<EmployeesDTO> lista2 = new LinkedList<EmployeesDTO>();
		List<Map<String,Object>> lista= new ArrayList<Map<String,Object>>(); 
		lista=this.jdbcUtils.queryForList("getEmployeesAll");
		
		for(Map<String,Object> map: lista ) {
				EmployeesDTO cliente= new EmployeesDTO();	
				cliente.setEmployeeNumber(Integer.parseInt(map.get("EMPLOYEE_NUMBER").toString()));
				cliente.setEmployeeName(map.get("EMPLOYEE_NAME").toString());
				cliente.setEmployeeDepartment(map.get("EMPLOYEE_DEPARTMENT").toString());
				cliente.setEmployeeRFC(map.get("EMPLOYEE_RFC").toString());
				cliente.setEmployeeEmail(map.get("EMPLOYEE_EMAIL").toString());
				cliente.setEmployeePhone(map.get("EMPLOYEE_PHONE").toString());
				cliente.setEmployeeAddress(map.get("EMPLOYEE_ADDRESS").toString());
				cliente.setEmployeeRegistrationDate((Date) map.get("EMPLOYEE_REGISTRATION_DATE"));
				cliente.setEmployeeStatus(Integer.parseInt(map.get("EMPLOYEE_STATUS").toString()));
				cliente.setEmployeeSalary(Integer.parseInt(map.get("SALARY").toString()));		
				
				lista2.add(cliente);
		}
		
		return lista2;
	}

	@Override
	public void execute() {
		// TODO - Implementation of business logic
	}

	public static boolean validarPhone(String Phone) {
		Pattern p = Pattern.compile("^\\d{10}$");
		Matcher m = p.matcher(Phone);

		return m.matches();
	}

	public static boolean validarCorreo(String correo) {
		Pattern p = Pattern.compile(
				"^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@" + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");
		Matcher m = p.matcher(correo);

		return m.find();

	}

	public static boolean validarRFC(String rfc) {
		rfc = rfc.toUpperCase().trim();
		return rfc.toUpperCase().matches(rfc);
	}
	
}
