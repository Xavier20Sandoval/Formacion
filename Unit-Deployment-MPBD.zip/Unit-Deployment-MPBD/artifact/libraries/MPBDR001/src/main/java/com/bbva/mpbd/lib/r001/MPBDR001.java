package com.bbva.mpbd.lib.r001;

import java.util.List;

import com.bbva.mpbd.dto.employees.EmployeesDTO;

/**
 * The  interface MPBDR001 class...
 */
public interface MPBDR001 {

	
	public EmployeesDTO executeInsert (EmployeesDTO employees);
	public void executeDeleteByName(EmployeesDTO employess);
	public EmployeesDTO executeUpdateByName(EmployeesDTO employees);
	public EmployeesDTO executeGetByName(EmployeesDTO employees);
	public List<EmployeesDTO> executeGetAll();
	
	
	
	void execute();

}
