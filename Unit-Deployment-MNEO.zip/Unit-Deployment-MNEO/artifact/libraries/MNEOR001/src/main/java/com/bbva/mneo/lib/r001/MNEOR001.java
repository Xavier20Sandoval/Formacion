package com.bbva.mneo.lib.r001;

import java.util.List;

import com.bbva.mneo.dto.customers.CustomersDTO;

/**
 * The  interface MNEOR001 class...
 */
public interface MNEOR001 {

	/**
	 * The execute method...
	 */
	//Los metodos dedben siempre ir en execute 
	public CustomersDTO executeInsert (CustomersDTO customer);
	public CustomersDTO executeUpadate (CustomersDTO customer);
	public void executeDeleteById (CustomersDTO customerDelete);
	public CustomersDTO executeGetByName (CustomersDTO customer);
	public void deleteAll();//ponerle executeDeleteAll
	public List<CustomersDTO> executeGetListCustomer(int pagZise, int index );//1,3,5,7,9..... , numero de paginacion donde se emepsara a leer 
	//public CustomersDTO executeGetByName (CustomersDTO customer);
	
	
	
	void execute();

}
