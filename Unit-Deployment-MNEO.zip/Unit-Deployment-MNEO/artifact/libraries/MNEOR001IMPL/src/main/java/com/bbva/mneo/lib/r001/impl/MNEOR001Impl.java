package com.bbva.mneo.lib.r001.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.bbva.apx.exception.db.DuplicateKeyException;
import com.bbva.apx.exception.db.NoResultException;
import com.bbva.apx.exception.db.TimeoutException;
import com.bbva.mneo.dto.customers.CustomersDTO;

/**
 * The MNEOR001Impl class...
 */
public class MNEOR001Impl extends MNEOR001Abstract {

	private static final Logger LOGGER = LoggerFactory.getLogger(MNEOR001Impl.class);
	//private 
	//Solo se pueden crear variables globales static final
	private static final String GETLISTCUSTOMER = "getListCustomer";
	

	/**
	 * The execute method...
	 */

	@Override
	public CustomersDTO executeInsert(CustomersDTO customer) {
		LOGGER.info("Entrando al metodo executeInsert");

		int result = 0;
		try {
			
			result = this.jdbcUtils.update("insert", customer.getCustomerId(), customer.getCustomerName(),
					customer.getAddress(), customer.getCity(), customer.getState(), customer.getZipCode());

		} catch (DuplicateKeyException e) {
			LOGGER.error("ocurrio un problema se duplico el key en la tabla de customer");
			addAdvice("MNEO01317004");
		} catch (TimeoutException e) {
			LOGGER.error("ocurrio un problema se excedio el tiempo para insertar en la tabla customers");
			addAdvice("MNEO01317005");
			// TODO: handle exception
		}
		LOGGER.info("El resultado del insert es {}", result);
		return customer;
	}

	@Override
	public CustomersDTO executeUpadate(CustomersDTO customerUpdate) {
		// TODO Auto-generated method stub
		LOGGER.info("Entrando al metodo executeUpdate");

		int result = 0;
		try {
			Map<String, Object> params = new HashMap<>();
			
			params.put("name",customerUpdate.getCustomerName() );
			params.put("address",customerUpdate.getAddress() );
			params.put("city",customerUpdate.getCity());
			params.put("state",customerUpdate.getState() );
			params.put("zip_code",customerUpdate.getZipCode() );
			params.put("id",customerUpdate.getCustomerId() );
			result = this.jdbcUtils.update("updateCustomer", params );

		} catch (DuplicateKeyException e) {
			LOGGER.error("ocurrio un problema se duplico el key en la tabla de customer");
			addAdvice("MNEO01317004");
			// TODO: handle exception
		} catch (TimeoutException e) {
			LOGGER.error("ocurrio un problema se excedio el tiempo para insertar en la tabla customers");
			addAdvice("MNEO01317004");
			// TODO: handle exception
		}
		LOGGER.info("El resultado del upate es {}", result);
		return customerUpdate;
	}
	
	@Override
	public void executeDeleteById(CustomersDTO customerDelete) {
		LOGGER.info("Entrando al metodo executeDeleteById");

		int result = 0;
		try {
			Map<String, Object> params = new HashMap<>();
			params.put("id", customerDelete.getCustomerId());
			result = this.jdbcUtils.update("delete", params);
		} catch (DuplicateKeyException e) {
			LOGGER.error("ocurrio un problema se duplico el key en la tabla de customer");
			addAdvice("MNEO01317004");
			// TODO: handle exception
		} catch (TimeoutException e) {
			LOGGER.error("ocurrio un problema se excedio el tiempo para insertar en la tabla customers");
			addAdvice("MNEO01317004");
			// TODO: handle exception
		}
		LOGGER.info("El resultado de delete es: ",result);
		
	}
	@Override
	public CustomersDTO executeGetByName(CustomersDTO customer) {
		// TODO Auto-generated method stub
		LOGGER.info("Entrando al metodo executeGetByNmabe");
		CustomersDTO cliente = new CustomersDTO();
		try {
			Map<String, Object> params = new HashMap<>();
			params.put("name", customer.getCustomerName());
			List<Map<String,Object>> lista = new ArrayList<Map<String, Object>>();
			lista = this.jdbcUtils.queryForList("getCustomer", params);
			
			if(lista.size() > 1)
			{
				LOGGER.info("Entrando a buscar el registro");
				for(Map<String, Object> map: lista) {
					if(customer.equals(map.get("CUSTOMER_NAME").toString())) {
						cliente.setCustomerId(Integer.parseInt(map.get("CUSTOMER_ID").toString()));
						cliente.setCustomerName(map.get("CUSTOMER_NAME").toString());
						cliente.setAddress(map.get("ADDRESS").toString());
						cliente.setCity(map.get("CITY").toString());
						cliente.setState(map.get("STATE").toString());
						cliente.setZipCode(map.get("ZIP_CODE").toString());
						break;
					}
					
				}
				LOGGER.info("Saliendo del if encontrar registros");
			}
			else {
				LOGGER.info("Entrando al else");
				cliente.setCustomerId(Integer.parseInt(lista.get(0).get("CUSTOMER_ID").toString()));
				cliente.setCustomerName(lista.get(0).get("CUSTOMER_NAME").toString());
				cliente.setAddress(lista.get(0).get("ADDRESS").toString());
				cliente.setCity(lista.get(0).get("CITY").toString());
				cliente.setState(lista.get(0).get("STATE").toString());
				cliente.setZipCode(lista.get(0).get("ZIP_CODE").toString());
			}
			LOGGER.info("Saliendo del else");
			
		} catch (NoResultException e) {
			LOGGER.error("Ocurrio un problema al obtener el customer DB");
			addAdvice("MNEO1317008");
			
		}
		
		LOGGER.info("Saliendo del metodo executeGetByName");
		return cliente;
	}
	@Override
	public void deleteAll() {
		// TODO Auto-generated method stub
		LOGGER.info("Entrando al metodo deleteAll");

		int result = 0;
		try {
			result = this.jdbcUtils.update("deleteAll");
		} catch (TimeoutException e) {
			LOGGER.error("Ocurrio un problema ");
			addAdvice("MNEO1317004");
		} catch (DuplicateKeyException e) {
			LOGGER.error("ocurrio un problema se excedio el tiempo para insertar en la tabla customers");
			addAdvice("MNEO1317004");
			// TODO: handle exception
		}
		LOGGER.info("El resultado de delete es{} ",result);
		
		
	}
	//Se puden agregar mas datos al de abajo para hacer una consulta
	@Override
	public List<CustomersDTO> executeGetListCustomer(int pagZise, int index) {
		// TODO Auto-generated method stub
		
		//Declaracion 
		List<CustomersDTO> listCustomer = new ArrayList<>();//donde se guardara los datos 
		
		List<Map<String, Object>> listMap=jdbcUtils.pagingQueryForList(GETLISTCUSTOMER, index,pagZise );
		
		if (listMap != null || !listMap.isEmpty()) {
			
			for(Map<String, Object> map : listMap) {
				
				CustomersDTO cliente = new CustomersDTO();//Para que no se repita la instancia 
				
				cliente.setCustomerId(Integer.parseInt(map.get("CUSTOMER_ID").toString()));
				cliente.setCustomerName(map.get("CUSTOMER_NAME").toString());
				cliente.setAddress(map.get("ADDRESS").toString());
				cliente.setCity(map.get("CITY").toString());
				cliente.setState(map.get("STATE").toString());
				cliente.setZipCode(map.get("ZIP_CODE").toString());
				
				listCustomer.add(cliente);
			}
			
		}
		
		return listCustomer;
	}

	@Override
	public void execute() {
		// TODO Auto-generated method stub

	}

	

	

	

	

}
