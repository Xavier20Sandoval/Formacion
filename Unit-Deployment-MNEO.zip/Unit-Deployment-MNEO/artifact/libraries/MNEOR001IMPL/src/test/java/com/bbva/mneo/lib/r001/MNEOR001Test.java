package com.bbva.mneo.lib.r001;

import com.bbva.apx.exception.db.DuplicateKeyException;
import com.bbva.apx.exception.db.NoResultException;
import com.bbva.elara.configuration.manager.application.ApplicationConfigurationService;
import com.bbva.elara.domain.transaction.Context;
import com.bbva.elara.domain.transaction.ThreadContext;
import com.bbva.mneo.dto.customers.CustomersDTO;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.Collections;
import java.util.concurrent.TimeoutException;

import javax.annotation.Resource;

import org.apache.velocity.runtime.directive.Parse;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.aop.framework.Advised;
import org.springframework.jdbc.support.JdbcUtils;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:/META-INF/spring/MNEOR001-app.xml",
		"classpath:/META-INF/spring/MNEOR001-app-test.xml", "classpath:/META-INF/spring/MNEOR001-arc.xml",
		"classpath:/META-INF/spring/MNEOR001-arc-test.xml" })
public class MNEOR001Test {

	private static final Logger LOGGER = LoggerFactory.getLogger(MNEOR001Test.class);

	private CustomersDTO customer;
	private Map<String, Object> paramsUpdate = new HashMap<>();
	private Map<String, Object> paramsDelete = new HashMap<>();
	private Map<String, Object> paramsGetByName = new HashMap<>();
	private List<Map<String,Object>> listaGetAll;
	private List<Map<String,Object>> listaGetByName;

	@Resource(name = "jdbcUtils")
	private com.bbva.elara.utility.jdbc.JdbcUtils jdbcUtils;
	@Spy
	private Context context;

	@Resource(name = "mneoR001")
	private MNEOR001 mneoR001;

	@Resource(name = "applicationConfigurationService")
	private ApplicationConfigurationService applicationConfigurationService;

	

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		context = new Context();
		ThreadContext.set(context);
		getObjectIntrospection();
		customer = new CustomersDTO();
		customer.setCustomerId(1);
		customer.setCustomerName("Marisol");
		customer.setAddress("Plan de ayala 13");
		customer.setCity("Tlaxcala");
		customer.setState("Tlaxcala");
		customer.setZipCode("90460");


		paramsUpdate.put("customerId", customer.getCustomerId());
		paramsUpdate.put("customerName", customer.getCustomerName());
		paramsUpdate.put("address", customer.getAddress());
		paramsUpdate.put("city", customer.getCity());
		paramsUpdate.put("state", customer.getState());
		paramsUpdate.put("zipCode", customer.getZipCode());

		paramsDelete.put("id", customer.getCustomerId());

		paramsGetByName.put("name", customer.getCustomerName());

		Map<String, Object> resGetByName = new HashMap<>();
		resGetByName.put("CUSTOMER_ID", customer.getCustomerId());
		resGetByName.put("CUSTOMER_NAME", customer.getCustomerName());
		resGetByName.put("ADDRESS", customer.getAddress());
		resGetByName.put("CITY", customer.getCity());
		resGetByName.put("STATE", customer.getState());
		resGetByName.put("ZIP_CODE", customer.getZipCode());

		listaGetByName = Arrays.asList(resGetByName);

		Map<String, Object> resGetByName2 = new HashMap<>();
		resGetByName2.put("CUSTOMER_ID", 2);
		resGetByName2.put("CUSTOMER_NAME", customer.getCustomerName());
		resGetByName2.put("ADDRESS", customer.getAddress());
		resGetByName2.put("CITY", customer.getCity());
		resGetByName2.put("STATE", customer.getState());
		resGetByName2.put("ZIP_CODE", customer.getZipCode());
		listaGetAll = Arrays.asList(resGetByName,resGetByName2);
	

	}

	private Object getObjectIntrospection() throws Exception {
		Object result = this.mneoR001;
		if (this.mneoR001 instanceof Advised) {
			Advised advised = (Advised) this.mneoR001;
			result = advised.getTargetSource().getTarget();
		}
		return result;
	}
	
	
	@Test
	public void executeTestInsert() {

		 mneoR001.executeInsert(customer);
		Mockito.verify(jdbcUtils, atLeastOnce()).update("insert", customer.getCustomerId(),
				customer.getCustomerName(),
				customer.getAddress(), customer.getCity(), customer.getState(),
				customer.getZipCode());
	}
	

	@Test
	public void executetDuplicateKeyExceptionTestInsertDuplicateKeyException() {

		Mockito.doThrow(new DuplicateKeyException("MNEO01317004")).when(jdbcUtils).update("insert",
				customer.getCustomerId(), customer.getCustomerName(),
				customer.getAddress(), customer.getCity(), customer.getState(),
				customer.getZipCode());
		mneoR001.executeInsert(customer);
		Mockito.verify(jdbcUtils, atLeastOnce()).update("insert",
				customer.getCustomerId(), customer.getCustomerName(),
				customer.getAddress(), customer.getCity(), customer.getState(),
				customer.getZipCode());
	}
	@Test
	public void executeTestUpdate() {
		
		
		Mockito.doThrow(new DuplicateKeyException("MNEO01317004")).when(jdbcUtils).update("insert",
				customer.getCustomerId(), customer.getCustomerName(),
				customer.getAddress(), customer.getCity(), customer.getState(),
				customer.getZipCode());
		mneoR001.executeInsert(customer);
		CustomersDTO resultado = mneoR001.executeUpadate(customer);
		Mockito.verify(jdbcUtils, atLeastOnce()).update("insert",
				customer.getCustomerId(), customer.getCustomerName(),
				customer.getAddress(), customer.getCity(), customer.getState(),
				customer.getZipCode());
		Assert.assertEquals(customer, resultado);
		
	}

	@Test
	public void executeTestUpdateDuplicateKeyException() {

		Mockito.doThrow(new DuplicateKeyException("MNEO01317004")).when(jdbcUtils).update("insert",
				customer.getCustomerId(), customer.getCustomerName(),
				customer.getAddress(), customer.getCity(), customer.getState(),
				customer.getZipCode());
		mneoR001.executeInsert(customer);
		CustomersDTO resultado = mneoR001.executeUpadate(customer);
		Mockito.verify(jdbcUtils, atLeastOnce()).update("insert",
				customer.getCustomerId(), customer.getCustomerName(),
				customer.getAddress(), customer.getCity(), customer.getState(),
				customer.getZipCode());
		Assert.assertEquals(customer, resultado);
		
		
	}
	@Test
	public void testDelete() {

		mneoR001.executeDeleteById(customer);
		Mockito.verify(jdbcUtils, atLeastOnce()).update("delete",paramsDelete);
	
	}
	@Test
	public void testGetByName() {
		Mockito.doReturn(listaGetAll).when(jdbcUtils).queryForList("getCustomer", paramsGetByName);
		//CustomersDTO result = 
		mneoR001.executeGetByName(customer);
		Mockito.verify(jdbcUtils, atLeastOnce()).queryForList("getCustomer",paramsGetByName);	
	}
	@Test
	public void testGetByNameOneRes() {
		Mockito.doReturn(listaGetByName).when(jdbcUtils).queryForList("getCustomer", paramsGetByName);
		CustomersDTO result = mneoR001.executeGetByName(customer);
		Mockito.verify(jdbcUtils, atLeastOnce()).queryForList("getCustomer",paramsGetByName);
		Assert.assertEquals(paramsGetByName.get("name"), result.getCustomerName());	
	}
	@Test
	public void TestGetByNameNoResultException() {

		Mockito.doThrow(new NoResultException("MNEO01317008")).when(jdbcUtils).queryForList("getCustomer", paramsGetByName);
		mneoR001.executeGetByName(customer);
		Mockito.verify(jdbcUtils, atLeastOnce()).queryForList("getCustomer", paramsGetByName);	
	}
	@Test
	public void testDeleteAll() {

		mneoR001.deleteAll();
		Mockito.verify(jdbcUtils, atLeastOnce()).update("deleteAll");
	
	}
	@Test
	public void executeGetListCustomerTest() {
		Mockito.doReturn(listaGetByName).when(jdbcUtils).pagingQueryForList("getListCustomer", 1,2);
		mneoR001.executeGetListCustomer(2,1);
		Mockito.verify(jdbcUtils, atLeastOnce()).pagingQueryForList("getListCustomer", 1,2);
		
	}

	@Test
	public void TestDeleteAllDuplicateKeyException() {
		Mockito.doThrow(new DuplicateKeyException("MNEO1317004")).when(jdbcUtils).update("deleteAll");
		
		mneoR001.deleteAll();
		Mockito.verify(jdbcUtils, atLeastOnce()).update("deleteAll");
		
	}
	

	
	@Test
	public void executeTest() {
		LOGGER.info("Executing the test...");
		mneoR001.execute();
		Assert.assertEquals(0, context.getAdviceList().size());
	}

	

}
